package com.cg.wallet.ui;


import java.util.Scanner;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.service.CustomerService;

public class MainCustomer {
	public static void main(String []args) {
		String name;
		boolean checkName,checkBalance;
		int ch = 0;
		char choice;
		long accNo,rAccNo;
		long availableBalance,depAmount,wAmount, withAmount,tAmount,tnsAmount;
		Long phn;
		Scanner sc= new Scanner(System.in);
		CustomerService cs=new CustomerService();
		// option menu
		do {
			System.out.println("Welcome To XYZ Bank Mobile Application");
			System.out.println("****************   Enter Your Choice    *****************");
			System.out.println("1.Create Account \n 2.Show Balance \n 3.Deposit \n 4.Withdraw \n 5.Fund Transfer 6.Exit");
			ch=sc.nextInt();
			sc.nextLine();
			switch(ch)
			{
			// To Create an account
			case 1:
				
				System.out.println("Enter your FULL NAME to create account");
				name=sc.nextLine();
					checkName=cs.isNameValid(name);
					Customer c=new Customer();
					if(checkName==true)
					{
						c.setName(name);
					}
					else
					{
						System.out.println("*************Invalid Name**************");
						break;
					}
					System.out.println("Enter your Mobile number");
					phn=sc.nextLong();
					boolean ph=cs.isPhoneValid(phn);
					if(ph==true)
					{
						c.setPhoneNumber(phn);
					}
					else
					{
						break;
					}
					c.setPhoneNumber(phn);
					c.setAccNumber(c.getPhoneNumber()+1010);
					System.out.println("Enter Balance [minimum:2000]");
					long bal=sc.nextLong();
					checkBalance=cs.isBalanceValid(bal);
					if(checkBalance==true)
					{
					c.setBalance(bal);
					}
					else
					{
						System.out.println("***************** Balance should be greater than 2000 *****************");
						break;
					}
				boolean result=cs.CreateAccount(c); 		//calling CreateAccount() in CustomerService class
				if (result==true)
				{
					System.out.println("************Account created successsfully**********");
					System.out.println("Account holder's name "+c.getName());
					System.out.println("Your account number is "+c.getAccNumber());
					System.out.println("Your balance is "+c.getBalance());
				}	
				break;
				//TO show the balance
			case 2:
				System.out.println("Enter Account number to Check Balance");
				accNo = sc.nextLong();
				availableBalance=cs.showBalance(accNo); 		//calling showBalance() in CustomerService class
				System.out.println("************* Available Balance in your Account is : "+availableBalance+"   **************");
				break;
				//To deposit the balance
			case 3:
				System.out.println("Enter the Account number in which you want to deposit money");
				accNo=sc.nextLong();
				System.out.println("Enter the amount you want to deposit");
				long dAmount=sc.nextLong();
				depAmount=cs.depositMoney(accNo,dAmount); 		//calling depositMoney() in CustomerService class
				System.out.println("*************Amount deposited Successfully************");
				System.out.println("Balance after deposit is : "+depAmount);
				break;
				//To withdraw the balance
			case 4:
				System.out.println("Enter the Account number from which you want to Withdraw money");
				accNo=sc.nextLong();
				System.out.println("Enter the amount you want to withdraw");
				wAmount=sc.nextLong();
				withAmount=cs.withdrawMoney(accNo,wAmount); 		//calling withdrawBalance() in CustomerService class
				System.out.println("************* After Withdrawing ************");
				System.out.println("Balance after withdrawn is : "+withAmount);
				break;
				// to Transfer funds
			case 5:
				System.out.println("Enter your account number");
				accNo=sc.nextLong();
				System.out.println("Enter the account number of reciever");
				rAccNo=sc.nextLong();
				System.out.println("Enter the amount you want to transfer");
				tAmount=sc.nextLong();
				tnsAmount=cs.fundTransfer(accNo, rAccNo, tAmount); 		//calling fundTransfer() in CustomerService class
				System.out.println("************** Funds Transferred Successfully ***************");
				System.out.println("Balance after Transferring amount is : "+tnsAmount);
				break;
				//To print transactions
			case 6:
				System.exit(0);
				break;
				//To terminate the Execution
			}
		System.out.println("Do you want to continue [y/n]??");
			choice=sc.next().charAt(0);
		}while(choice != 'n'); 						
		sc.close();
	}
}

