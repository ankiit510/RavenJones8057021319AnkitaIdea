package com.cg.wallet.service;

import com.cg.wallet.bean.Customer;

public interface InterfaceOfService {
	public boolean isPhoneValid(Long phn);
	public boolean isNameValid(String name);
	public boolean CreateAccount(Customer customer);
	public long showBalance(long accNo);
	public long depositMoney(long accNo,long amount);
	public long withdrawMoney(long accNo, long amount);
	public long fundTransfer(long senderAccNo,long recieverAccNo,long amount );

}
