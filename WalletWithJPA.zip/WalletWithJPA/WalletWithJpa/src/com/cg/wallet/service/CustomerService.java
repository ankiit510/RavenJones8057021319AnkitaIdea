package com.cg.wallet.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.dao.CustomerDao;

public class CustomerService implements InterfaceOfService {
	Customer c=new Customer();
	CustomerDao dao=new CustomerDao();
	/***************************************************************************************
	 * method name: isPhoneValid
	 * return type: boolean 
	 * argument type: Long
	 */
	public boolean isPhoneValid(Long phn)
	{
		boolean b=false;
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(phn.toString());
		if(m.matches())
		{
			b=true;
		}
		else
		{
			System.out.println("************* Enter valid phone number ************");
		}
	return b;
	}
	/***************************************************************************************
	 * method name: isNameValid
	 * return type: boolean 
	 * argument type: String
	 */
	public boolean isNameValid(String name)
	{
		boolean bol=false;
		if(Pattern.matches("^([A-Z]*[a-z]*((\\s)))+[A-Z]*[a-z]*$", name))		// regex pattern that accepts first name and last name
		{
			bol= true;
		}
		return bol;
	}
	/***************************************************************************************
	 * method name: isBalanceValid
	 * return type: boolean 
	 * argument type: double
	 */
	public boolean isBalanceValid(double bal) {
		boolean p=false;
		if(bal>=2000)
		{
			p=true;
		}
		return p;
	}
	/***************************************************************************************
	 * method name: CreateAccount
	 * return type: boolean 
	 * argument type: Customer
	 */
	public boolean CreateAccount(Customer customer)
	{
		boolean res=dao.inputDetail(customer);		//calling inputDetail() of CustomerDao class
		return res;
	}
	/***************************************************************************************
	 * method name: showBalance
	 * return type: double 
	 * argument type: long
	 */
	public long showBalance(long accNo) {
		long balance=dao.showBalance(accNo);		//calling showBalance() of CustomerDao class
		return balance;
	}
	/***************************************************************************************
	 * method name: depositMoney
	 * return type: double
	 * argument type: long,double
	 */
	public long depositMoney(long accNo,long amount)
	{	
		long dAmt=dao.deposit(accNo,amount);		//calling deposit() of CustomerDao class
		return dAmt;
		
	}
	/***************************************************************************************
	 * method name: withdrawMoney
	 * return type: double
	 * argument type: long,double
	 */
	public long withdrawMoney(long accNo, long amount)
	{
		long wAmt=dao.withdraw(accNo,amount);		//calling withdraw() of CustomerDao class
		return wAmt;
	}
	/***************************************************************************************
	 * method name: fundTransfer
	 * return type: double
	 * argument type: long,long,double
	 */
	public long fundTransfer(long accNo,long rAccNo,long tAmount )
	{
		long balance=dao.transferFund(accNo, rAccNo, tAmount);		//calling transferFund() of CustomerDao class
		return balance;
	}
}
