package com.cg.wallet.dao;

import com.cg.wallet.bean.Customer;

public interface InterfaceOfDao {
	public boolean inputDetail(Customer customer);
	public long showBalance(long accNo);
	public long deposit(long accNo, long amount);
	public long withdraw(long accNo, long amount);
	public long transferFund(long senderAccNo, long recieverAccNo, long amount);
	

}
