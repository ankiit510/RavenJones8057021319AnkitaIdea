package com.cg.wallet.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import com.cg.wallet.bean.Customer;

import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class CustomerDao implements InterfaceOfDao {
	Customer c=new Customer();
	EntityManagerFactory emf=null;
	EntityManager em=null;
	/***************************************************************************************
	 * method name: inputDetail
	 * return type: boolean 
	 * argument type: Customer
	 */
	public boolean inputDetail(Customer customer)
	{
		this.c=customer;
		//map.put(c.getAccNumber(), customer);
		emf=Persistence.createEntityManagerFactory("WalletWithJpa");
		em=emf.createEntityManager();
		em.getTransaction().begin();
		//c.transaction=null;
		em.persist(c);
		em.getTransaction().commit();
		return true;
	}
	/***************************************************************************************
	 * method name: showBalance
	 * return type: double
	 * argument type: double
	 */
	public long showBalance(long accNo) {
		long balance=0;
				emf=Persistence.createEntityManagerFactory("WalletWithJpa");
				em=emf.createEntityManager();
				em.getTransaction().begin();
				Customer cus=em.find(Customer.class, accNo);
				balance=(long) cus.getBalance();
				em.getTransaction().commit();
			
		
		
		return balance;
	}
	/***************************************************************************************
	 * method name: deposit
	 * return type: double 
	 * argument type: long,double
	 */
	public long deposit(long accNo, long amount) {
		long balance=0;
		emf=Persistence.createEntityManagerFactory("WalletWithJpa");
		em=emf.createEntityManager();
		em.getTransaction().begin();
		Customer cus=em.find(Customer.class, accNo);
		balance=(long) cus.getBalance();
		balance=balance+amount;
		cus.setBalance(balance);
		em.persist(cus);
		em.getTransaction().commit();
	
		
		return balance;
	}
	/***************************************************************************************
	 * method name: withdraw
	 * return type: double 
	 * argument type: long,double
	 */
	public long withdraw(long accNo, long amount) {
		long balance=0;
		
		emf=Persistence.createEntityManagerFactory("WalletWithJpa");
		em=emf.createEntityManager();
		em.getTransaction().begin();
		Customer cus=em.find(Customer.class, accNo);
		balance=(long) cus.getBalance();
		balance=balance-amount;
		cus.setBalance(balance);
		em.persist(cus);
		em.getTransaction().commit();
	
		
		return balance;
	}
	/***************************************************************************************
	 * method name: transferFund
	 * return type: double 
	 * argument type: long,long,double
	 */
	public long transferFund(long accNo,long rAccNo,long tAmount) {
		long balance=0;
		long rbal=0;
		emf=Persistence.createEntityManagerFactory("WalletWithJpa");
		em=emf.createEntityManager();
		em.getTransaction().begin();
		Customer cus=em.find(Customer.class, accNo);
		balance=(long) cus.getBalance();
		balance=balance-tAmount;
		cus.setBalance(balance);
		em.persist(cus);
		em.getTransaction().commit();
		
		emf=Persistence.createEntityManagerFactory("WalletWithJpa");
		em=emf.createEntityManager();
		em.getTransaction().begin();
		cus=em.find(Customer.class, rAccNo);
		rbal=(long) cus.getBalance();
		rbal=rbal+tAmount;
		cus.setBalance(rbal);
		em.persist(cus);
		em.getTransaction().commit();
		return balance;
	}
}
		
	
	
	
	
	
	
	
	

